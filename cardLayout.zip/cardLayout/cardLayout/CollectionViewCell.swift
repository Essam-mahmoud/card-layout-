//
//  CollectionViewCell.swift
//  cardLayout
//
//  Created by Essam Mahmoud fathy on 11/5/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var locationImage: UIImageView!
    
    @IBOutlet weak var locationName: UILabel!
    @IBOutlet weak var locationDescription: UILabel!
}
